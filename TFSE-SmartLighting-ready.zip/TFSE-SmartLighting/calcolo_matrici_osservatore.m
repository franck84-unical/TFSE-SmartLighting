%% AGENTS OBSERVERS

%% Agent 1
L111 = observer(A1,C11,F11,F11);
L121 = L111;
L131 = L111;
%% Agent 2
L222 = observer(A2,C22,F22,F22);
L232 = L222;
L242 = L222;
%% Agent 3
L333 = observer(A3,C33,F33,F33);
L343 = L333;
L353 = L333;
%% Agent 4
L444 = observer(A4,C44,F44,F44);
L454 = L444;
L464 = L444;
%% Agent 5
L555 = observer(A5,C55,F55,F55);
L565 = L555;
L515 = L555;

yalmip('clear')